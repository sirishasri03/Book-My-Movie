//Heading.JS for Upgrad React project

import React from "react";
import "./Heading.css";

const Heading = () => {
  return (
    <div>
      <p className="heading">Upcoming Movies</p>
    </div>
  );
};

export default Heading;